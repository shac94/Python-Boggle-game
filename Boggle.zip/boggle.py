import tkinter as tki
import boggle_board_randomizer as helper
import boggle_GUI

# number of milliseconds (for the after function)
SECOND = 1000


class MyApp:
    """
    This class is the core of the game. It controls and changes the game by
    the player's action. All the functional of the game are set in this class
    """
    _INITIAL_SCORE = 0
    _INITIAL_TIME = 180

    # parameters that represents the word status after getting it from screen
    _LEGAL_WORD = 1
    _ILLEGAL_WORD = 2
    _ALREADY_FOUNDED = 3

    def __init__(self, words_set, game_board):
        """
        The constructor of the class
        :param words_set: set of words that are legal in this game
        :param game_board: 2D list of letters (strings)
        """
        self.__score = self._INITIAL_SCORE
        self.__time = self._INITIAL_TIME
        self.__word_founded = []
        self.__legal_words = words_set
        self.__board = game_board
        self.__game_started = False

        self.__root = tki.Tk()
        self.__root.attributes("-fullscreen", True)
        self.__screen = boggle_GUI.GUI(self.__root, self.__board, self)
        self.__root.after(SECOND, self.update_time())
        self.__root.mainloop()

    def get_time(self):
        """
        This method returns the current time the player have left
        """
        return self.__time

    def get_score(self):
        """
        :return: the player's score
        """
        return self.__score

    def get_board(self):
        """
        :return: the game board
        """
        return self.__board

    def set_game_started(self, boolean):
        """
        This method changes the 'game_started' attribute to the given
        boolean expression, so that the time's methods will know if the time
        should run or not.
        :param boolean: True/False
        :return: None
        """
        self.__game_started = boolean

    def update_time(self):
        """
        This method updates the time the player have by using the 'after'
        function
        :return: None
        """
        if self.__game_started:
            self.__time -= 1
            self.__screen.update_time(self.__time)

        self.__root.after(SECOND, lambda: self.update_time())

    def update_score(self, word):
        """
        This method updates the player score by adding to it the word's length
        squared
        :param word: the founded word
        :return: None
        """
        if self.__game_started:
            self.__score += (len(word) - 1) ** 2
            self.__word_founded.append(word)
            self.__screen.update_after_send(self.__score, word)

    def is_available_word(self, word):
        """
        This method receives a word from "send word" method of the GUI class
        and checks if the word is in the game's legal words and if it
        wasn't founded already. It returns a number indicates the word's
        status
        :param word: ""
        :return: number that indicates the word's status
        """
        if word in self.__word_founded:
            return self._ALREADY_FOUNDED

        if word in self.__legal_words:
            self.update_score(word)
            return self._LEGAL_WORD

        return self._ILLEGAL_WORD

    def reset_game(self):
        """
        This method resets the game attributes: time, score, word founded
        and board. It's used when the player restart the game
        :return: None
        """
        self.__time = self._INITIAL_TIME
        self.__score = self._INITIAL_SCORE
        self.__word_founded = []
        self.__board = helper.randomize_board()

    def exit_game(self,):
        """
        This method destroys the game root used when the player wants to exit
        the game
        :return: None
        """
        self.__root.destroy()


def get_from_file(filename):
    """
    This function opens a file, read it and returns a set contains all the
    words in the file
    :param filename: specific file name
    :return: words set
    """
    words = set()
    with open(filename, 'r') as file:
        for word in file:
            words.add(word)
    return words


if __name__ == "__main__":
    legal_words = get_from_file("boggle_dict.txt")
    board = helper.randomize_board()
    MyApp(legal_words, board)
