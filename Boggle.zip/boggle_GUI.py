import tkinter as tki
from tkinter import messagebox

# in used for the clock:
SECONDS_IN_MINUTE = 60
TOTAL_CIRCLE_ANGLES = 360


class GUI:
    """
    This class is responsible for the entire game display.
    The game view is built on a library named "tkinter". In this class we
    build the canvases, buttons, and everything that is visual in our game
    """
    # general font of the game
    _GAME_FONT = "comic sans ms"

    # the player's time at the beginning and the end of the game
    _INITIAL_TIME = 180
    _GAME_OVER_TIME = 0

    # parameters for calculating the location of every canvas in the board
    _FIRST_SPOT = 5
    _BUTTONS_DISTANCE = 95
    _BUTTON_LENGTH = 80

    # dictionary of word's color when:
    # 1 = Legal word
    # 2 = Illegal word
    # 3 = Word that was already chosen
    _WORDS_COLORING = {1: "yellowgreen", 2: "tomato", 3: "lightseagreen"}

    # indexes of the canvases dictionary:

    # indexes of the canvas location
    _X_START = 0
    _X_END = 1
    _Y_START = 2
    _Y_END = 3

    # the dictionary's keys and values indexes
    _COORD = 0
    _VALUE = 1
    _BORDER = 0
    _CENTER = 1
    _GRID_LOCATION = 2

    def __init__(self, root, board, game):
        """
        The constructor of the class
        :param root: The root that will contain the game's widgets
        :param board: 2D list of letters (strings)
        :param game: The game that is represented by this graphic
        """
        self.__root = root
        self.__parent = None
        self.__board = board
        self.__game = game
        self.__path = []
        self.__buttons = {}
        self.__word_lst, self.__score, self.__buttons_frame, self.__clock = \
            None, None, None, None
        self.__background = tki.PhotoImage(file='jungle bg.PNG')
        self.__start_button_img = tki.PhotoImage(file='start.PNG')
        self.__exit_button_img = tki.PhotoImage(file='exit.PNG')

        # create the start screen:
        self.start_screen()

    def basic_screen(self):
        """
        This method builds the basic screen which contains the main canvas
        and an exit button.
        :return: None
        """
        # build the main canvas
        self.__parent = tki.Canvas(self.__root)
        self.__parent.pack(expand=True, fill=tki.BOTH)

        # add an image background
        self.__parent.create_image(0, 0, image=self.__background,
                                   anchor=tki.NW)

        # create an exit button with image
        exit_button = tki.Button(self.__parent, bg='red', width=100, height=40,
                                 command=lambda: self.exit_game(),
                                 image=self.__exit_button_img)
        exit_button.place(x=1250, y=15)

    def start_screen(self):
        """
        This method creates the start screen of the game, which contains the
        game title and a button which starts the game when clicking on it.
        :return: None
        """
        # build the basic screen
        self.basic_screen()

        # add the start button with image
        start_button = tki.Button(self.__parent, image=self.__start_button_img,
                                  command=lambda: self.switch_screen())
        start_button.place(x=565, y=350)

        # add the game title
        welcome_msg = "Welcome to the ultimate Boggle Game!"
        self.__parent.create_text(700, 270, font=(self._GAME_FONT, 45, 'bold'),
                                  fill="dodgerblue", text=welcome_msg)

    def switch_screen(self):
        """
        This method is used when the player clicks the "start button".
        It destroys the start screen and build the main game screen.
        :return: None
        """
        self.__parent.destroy()
        self.build_game_screen()

        # change the boolean expression in the game class, so that the clock
        # will start running
        self.__game.set_game_started(True)

    def build_game_screen(self):
        """
        This method is used after the player clicked the start button,
        and the start screen was destroyed.
        It builds the main game screen which contains the letters board,
        the player's score, time and list of words that were founded
        :return: None
        """
        # build the basic screen
        self.basic_screen()

        # add text titles
        self.__parent.create_text(400, 400, text="Score:",
                                  font=(self._GAME_FONT, 30), fill="green")
        self.__score = self.__parent.create_text(400, 455, text="0",
                                                 font=(self._GAME_FONT, 30),
                                                 fill="green")

        # add the buttons to the board game
        self.__buttons_frame = tki.Frame(self.__parent, cursor="spider")
        self.__buttons_frame.place(x=500, y=130)
        self.create_board(self.__buttons_frame)

        # add list box and scroll bar to the board game
        words_frame = tki.Frame(self.__parent)
        words_frame.place(x=900, y=180)

        scrollbar = tki.Scrollbar(words_frame, width=20, background="honeydew")
        scrollbar.pack(side=tki.RIGHT, fill=tki.Y)
        self.__word_lst = tki.Listbox(words_frame, font=(self._GAME_FONT, 15),
                                      width=12, yscrollcommand=scrollbar.set,
                                      fg="green")
        self.__word_lst.pack(side=tki.LEFT, fill=tki.BOTH)
        scrollbar.config(command=self.__word_lst.yview)
        self.__parent.create_text(980, 160, text="Words Founded:",
                                  font=(self._GAME_FONT, 16), fill="green")

        # add clock to the game screen
        # self.build_clock(self._INITIAL_TIME)
        self.update_time(self._INITIAL_TIME)

    def create_board(self, board_frame):
        """
        This method builds the game board: 4X4 board which is made of
        canvases. every canvas contains a letter from the "self.__board",
        and responses for:
        1. mouse moving while clicking the left button
        2. mouse's left button release
        :param board_frame: The frame which contains the board
        :return: None
        """
        for row in range(len(self.__board)):
            for ltr in range(len(self.__board[0])):

                # build a canvas that will contain a letter
                border = tki.Canvas(board_frame, width=90, height=90,
                                    bg='floralwhite')
                my_button = border.create_rectangle(5, 5, 85, 85, fill="peru")
                border.create_text(45, 45, text=self.__board[row][ltr],
                                   font=(self._GAME_FONT, 20))

                # calculate the coordinates of this canvas'es inner rectangle
                start_x = self._FIRST_SPOT + ltr * self._BUTTONS_DISTANCE
                start_y = self._FIRST_SPOT + row * self._BUTTONS_DISTANCE
                end_x = start_x + self._BUTTON_LENGTH
                end_y = start_y + self._BUTTON_LENGTH
                coord = (start_x, end_x, start_y, end_y)

                # add the canvas to the dictionary
                self.__buttons[coord] = border, my_button, (ltr, row)

                # place it on the frame
                border.grid(row=row, column=ltr)

        # add the functionality for the canvases
        board_frame.bind_all("<B1-Motion>",
                             lambda event: self.get_letters(event, board_frame,
                                                            my_button), True)
        board_frame.bind_all("<ButtonRelease>", lambda event: self.send_word(),
                             True)

    def get_letters(self, event, frame, my_button):
        """
        This method is used when the player drags the mouse while the left
        button is pressed.
        It recognizes if the mouse is on one of the board's canvases. If it
        is and the canvas is a 'neighbor' of the last chosen canvas - it
        adds it to the path list
        :param event: "B1-Motion" event
        :param frame: the board frame
        :param my_button: the inner canvas'es rectangle, which is the
        'active part' of the canvas
        :return: None
        """
        cur_button = None

        # find the location relative to the board frame
        x_spot = event.x_root - self.__parent.winfo_rootx() - frame.winfo_x()
        y_spot = event.y_root - self.__parent.winfo_rooty() - frame.winfo_y()

        # checks if the location is on one of the canvases
        for key in self.__buttons:
            if x_spot in range(key[self._X_START], key[self._X_END]) and \
                    y_spot in range(key[self._Y_START], key[self._Y_END]):
                cur_button = key, self.__buttons[key]
                break

        if cur_button is not None and cur_button not in self.__path:
            cur_coord = cur_button[self._COORD]
            border = cur_button[self._VALUE][self._BORDER]

            if len(self.__path) == 0:
                self.__path.append(cur_button)
                border.itemconfig(my_button, fill="burlywood")

            else:  # need to check if this canvas is neighbor of the last one
                last_coord = self.__path[-1][self._COORD]
                x_dist = cur_coord[self._X_START] - last_coord[self._X_START]
                y_dist = cur_coord[self._Y_START] - last_coord[self._Y_START]

                if abs(x_dist) <= self._BUTTONS_DISTANCE and abs(y_dist) <= \
                        self._BUTTONS_DISTANCE:
                    # they are neighbors
                    self.__path.append(cur_button)
                    cur_button[self._VALUE][self._BORDER].itemconfig(
                        my_button, fill="burlywood")

    def send_word(self):
        """
        This method sends the marked word to check if the word is legal.
        If it's legal it inserts the word to the words founded list in the
        scrollbar display
        :return: None
        """
        coord_lst = []

        for button in self.__path:
            coord_lst.append(button[self._VALUE][self._GRID_LOCATION])

        # convert to uppercase string
        word = "".join(self.__board[col][row].upper() for row, col in
                       coord_lst) + '\n'

        # color the word so that the player knows if it's legal or not:
        color = self.__game.is_available_word(word)

        for button in self.__path:
            button[self._VALUE][self._BORDER].itemconfig(
                button[self._VALUE][self._CENTER],
                fill=self._WORDS_COLORING[color])

        # copy the list in order to be able to reset the color of the canvases
        path_copy = self.__path[:]
        self.__parent.after(200, lambda: self.reset_canvas_color(path_copy))
        self.__path = []

    def reset_canvas_color(self, path):
        """
        This method resets the canvases color after showing the player if
        the word was legal or not.
        :param path: list of the buttons that the player chose
        :return: None
        """
        for button in path:
            button[self._VALUE][self._BORDER].itemconfig(
                button[self._VALUE][self._CENTER], fill="peru")

    def update_after_send(self, score, new_word):
        """
        This method updates the score and the word founded list on the screen
        :param score: ""
        :param new_word: a word that the player has found
        :return: None
        """
        self.__word_lst.insert(0, new_word)
        self.__parent.itemconfig(self.__score, text=f"{score}")

    def update_time(self, time):
        """
        This method updates the time display on the screen.
        If the game is over it calls the 'rematch' method.
        :param time: ""
        :return: None
        """
        if self.__game.get_time() < self._INITIAL_TIME - 1:
            self.__clock.destroy()

        # build the clock
        self.__clock = tki.Canvas(self.__parent, bg="whitesmoke",
                                  height=160, width=160)

        # calculation for the angles of the arcs
        time_pass = TOTAL_CIRCLE_ANGLES - time * 2
        if time == 0:
            time_pass = TOTAL_CIRCLE_ANGLES - 1

        self.__clock.create_arc(5, 5, 150, 150, start=90, extent=time_pass,
                                fill="tomato")
        self.__clock.create_arc(5, 5, 150, 150, start=90 + time_pass,
                                fill="lightskyblue", extent=359 - time_pass)
        self.__clock.create_oval(25, 25, 130, 130, fill="darkcyan")

        # update the time on the screen
        clock_minutes = time // SECONDS_IN_MINUTE
        seconds = time % SECONDS_IN_MINUTE
        clock_seconds = f"{seconds // 10}{seconds % 10}"
        clock_time = f"{clock_minutes}:{clock_seconds}"
        self.__clock.create_text(78, 75, text=clock_time, font=(
            self._GAME_FONT, 20))

        self.__clock.place(x=320, y=190)
        if self.__game.get_time() == self._GAME_OVER_TIME:
            self.rematch()
            return

    def rematch(self):
        """
        This method is used when the player time is up.
        It shows the player a message box containing his score, and asks him
        to choose between play again or exit.
        If the player chose to play again, it resets the game.
        If the player chose to exit it uses the method 'exit_game' to exit.
        :return: None
        """
        # update the game that the time is up (so that the clock will stop
        # running)
        self.__game.set_game_started(False)

        msg = f"Your score is: {self.__game.get_score()}." \
              f"\nDo you want to play again?"
        if tki.messagebox.askquestion(title="Time's up!", message=msg) == \
                "yes":
            self.__buttons_frame.unbind_all("<B1-Motion>")
            self.__buttons_frame.unbind_all("<ButtonRelease>")
            self.__parent.destroy()
            self.__game.reset_game()
            self.__board = self.__game.get_board()
            self.__game.set_game_started(True)
            self.build_game_screen()

        else:
            self.exit_game()

    def exit_game(self):
        """
        This method is used when the player wants to exit after a game
        iteration or when the player clicks the exit button.
        The method uses the 'exit_game' method of the MyApp class
        which destroys the game root and by that closes the game window.
        :return: None
        """
        self.__game.exit_game()
